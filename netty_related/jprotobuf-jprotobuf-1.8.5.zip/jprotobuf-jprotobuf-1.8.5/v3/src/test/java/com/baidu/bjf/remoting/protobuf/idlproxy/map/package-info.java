
/**
 * Test for map type parser from proto IDL
 * 
 * @author xiemalin
 * @since 2.0.0.0
 */
package com.baidu.bjf.remoting.protobuf.idlproxy.map;